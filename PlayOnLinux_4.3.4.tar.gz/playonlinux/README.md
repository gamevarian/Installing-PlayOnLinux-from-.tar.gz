POL-POM-4
=========

PlayOnLinux 4 repository
Note: PlayOnLinux 5 is currently under development. Please clone POL-POM-5 repository if you want to contribute

What is PlayOnLinux?
=====================

PlayOnLinux is a piece of software which allows you to easily install and use numerous games and apps designed to run with Microsoft® Windows®.
Few games are compatible with GNU/Linux at the moment and it certainly is a factor preventing the migration to this system. PlayOnLinux brings a cost-free, accessible and efficient solution to this problem.


What are PlayOnLinux's features?
================================

Here is a non-exhaustive list of the interesting points to know:

You don't have to own a Windows license to use PlayOnLinux.
PlayOnLinux is based on Wine, and so profits from all its features yet it keeps the user from having to deal with its complexity.
PlayOnLinux is free software.
PlayOnLinux uses Bash and Python.
Nevertheless, PlayOnLinux has some bugs, as every piece of software:

Occasional performance decrease (image may be less fluid and graphics less detailed).
Not all games are supported. Nevertheless, you can use our manual installation module.

For more information, visit http://www.playonlinux.com
